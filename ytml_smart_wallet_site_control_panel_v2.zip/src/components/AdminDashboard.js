import React from 'react';
import { Card, Elevation, Button } from '@blueprintjs/core';

function AdminDashboard() {
  return (
    <div style={{ padding: '30px' }}>
      <Card elevation={Elevation.TWO}>
        <h2>Admin Control Panel</h2>
        <p>Manage users, view logs, and interact with the database.</p>
        <div style={{ marginTop: '20px' }}>
          <Button intent="primary" text="View Wallet Logs" />
          <Button intent="success" text="Sync Database" style={{ marginLeft: '10px' }} />
          <Button intent="warning" text="Send Announcement" style={{ marginLeft: '10px' }} />
        </div>
      </Card>
    </div>
  );
}

export default AdminDashboard;
