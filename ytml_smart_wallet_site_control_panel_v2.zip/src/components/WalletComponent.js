import React, { useEffect } from 'react';
import { CoinbaseWalletSDK } from '@coinbase/wallet-sdk';

function WalletComponent() {
  useEffect(() => {
    const walletLink = new CoinbaseWalletSDK({
      appName: "Smart Wallet Portal",
      darkMode: true
    });

    const ethereum = walletLink.makeWeb3Provider("https://mainnet.infura.io/v3/<INFURA_API_KEY>", 1);
    console.log("Coinbase Wallet SDK initialized:", ethereum);
  }, []);

  return (
    <div>
      <p>Connect your wallet using Coinbase SDK</p>
    </div>
  );
}

export default WalletComponent;
