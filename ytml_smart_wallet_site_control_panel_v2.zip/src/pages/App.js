import React from 'react';
import WalletComponent from '../components/WalletComponent';
import AdminDashboard from '../components/AdminDashboard';

function App() {
  return (
    <div className="bp4-dark">
      <h1>Smart Wallet Portal</h1>
      <WalletComponent />
      <AdminDashboard />
    </div>
  );
}

export default App;
